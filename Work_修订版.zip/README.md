# 《AI Agents in Action》第二版 · 第 1–6 章 中文辅助阅读讲义

## 文件结构

```
Work/
├── main.tex              主文件（封面、阅读说明、目录、章节引入）
├── chapters/
│   ├── ch01.tex          第 1 章  AI 智能体的崛起
│   ├── ch02.tex          第 2 章  核心构件：大语言模型、提示词与智能体
│   ├── ch03.tex          第 3 章  用模型上下文协议连接智能体与工具
│   ├── ch04.tex          第 4 章  架构与构建多智能体系统
│   ├── ch05.tex          第 5 章  智能体的推理与规划
│   └── ch06.tex          第 6 章  为智能体打造记忆与知识 RAG
├── style/
│   └── lecturestyle.sty  版面样式包（配色、字体、代码框、注释框、表格）
├── figures/              原书插图 66 张（CH01–CH06 全部）
├── 预览.pdf              已编译成品（244 页）
└── 审校报告.md           独立审校记录（不进入正文）
```

## 编译

```bash
xelatex main.tex && xelatex main.tex      # 两遍以生成目录与交叉引用
# 或
latexmk -xelatex main.tex
# 或
tectonic main.tex
```

需要 XeLaTeX + ctex + xeCJK，以及 tcolorbox / listings / tabularx / booktabs / titlesec / fancyhdr 等常见宏包。

## 换字体

只改 `style/lecturestyle.sty` 顶部「字体」一节的六行即可，版式与字体解耦：

```latex
\setmainfont{DejaVu Serif}              % 西文正文
\setCJKmainfont{Noto Serif CJK SC}      % 中文正文（可换思源宋体 Source Han Serif SC）
\newCJKfontfamily\cjkheading{Noto Sans CJK SC}   % 标题黑体
```

## 自定义命令速查

| 命令 | 用途 |
|---|---|
| `\chapterhead{1}{标题}` | 章标题（巨号数字 + 双线） |
| `\bookfigure{文件名}{宽度}{图注}{标签}` | 插图 |
| `\code{...}` | 行内代码（浅底圆角） |
| `\tcode{...}` | 表格内可断行的行内代码 |
| `\term{...}` | 术语强调 |
| `\jargon{中文}{English}` | 术语首现标注 |
| `codelisting` 环境 | 带标题的代码清单（可跨页） |
| `longtable` | 超长表格跨页（如表 2.2） |
| `annotations` 环境 | 代码标注（▷ 列表） |
| `notebox` / `tipbox` / `warnbox` | 注意 / 提示 / 警告框 |
| `chaptercovers` / `exercisebox` | 章前提要 / 动手练习 |
