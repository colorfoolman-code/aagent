# AI 智能体开发入门：语言与版式修订版

本修订包依据指定的 `Work_修订版.zip` 制作。仅获取该 ZIP，未获取源仓库其他文件。

## 本轮范围

- 逐行审读并润色第 4 至 6 章，共 2,943 行原始 LaTeX。
- 调整句式、标题、术语、图注及中文代码标注；对明显有歧义的技术表述作澄清，并单独记录。
- 全书共用版式升级：留白、字体回退、标题层级、页眉页码、代码清单、图注及长表格。
- 第 1 至 3 章正文、66 张插图、原有代码清单不作内容修改。
- 未与英文原书逐句核对，未运行书中 Python 代码。该讲义仅供个人学习，请支持正版。

## 文件说明

`main.tex`：全书编译入口。

`chapters/`：六章 LaTeX 源文件，第 4 至 6 章已修订。

`style/lecturestyle.sty`：全书共享样式。

`figures/`：原有 66 张插图。

`REVISION_REPORT.md`：本轮工作范围、统计、校验与版式说明。

`CHANGES.md`、`CHANGES.json`：按原稿行号保存的完整修订对照。

`TECHNICAL_REVIEW.md`：代码疑点、表述澄清和未验证事项。

`COMPILATION_STATUS.json`、`compilation.log`：实际编译状态与日志，不能用网页构建成功代替 LaTeX 编译成功。

`reference/original-preview.pdf`：ZIP 中原有的历史预览，不是修订版 PDF。

`reference/original-audit.md`：ZIP 中原有的历史审校记录，不是本轮报告。

若本次 Tectonic 编译成功，根目录还会包含 `main.pdf`。否则请按下面说明本地编译。

## 安装 Tectonic 并检查编译

macOS（需要 Homebrew）：

```sh
brew install tectonic
```

Windows / Linux / macOS（需要先安装 Conda）：

```sh
conda install -c conda-forge tectonic
```

无包管理器时，可从官方发行页面下载与操作系统和处理器架构相符的程序，解压并加入 PATH：

https://github.com/tectonic-typesetting/tectonic/releases

安装说明：https://tectonic-typesetting.github.io/book/latest/installation/

解压 ZIP 后，在 `Work_revised` 目录内运行：

```sh
tectonic --version
tectonic -X compile main.tex --keep-logs --untrusted
```

首次运行需要联网下载 TeX 宏包与字体资源；后续会使用缓存。`--untrusted` 禁用已知不安全特性，书稿不需要 shell escape。退出码为零并生成 `main.pdf`，才表示编译完成。目录与引用由 Tectonic 自动处理，但仍需检查日志和 PDF 版面。

优先使用 Noto Serif CJK SC / Noto Sans CJK SC，未安装时自动回退到 Fandol。西文字体使用 TeX 资源中的 TeX Gyre 与 Latin Modern。若资源下载失败，请检查网络、代理或缓存，不要把依赖缺失误判为源稿编译通过。

## 复核重点

- 查看日志中的未定义引用、字体缺字、Overfull 和浮动体警告。
- 检查第 4 与第 6 章的跨页表格表头是否重复、内容是否完整。
- 检查代码行号、折行和中文标注的对应关系。
- 检查封面、目录、页眉、章首页与图注的间距。
- 字体更换可能改变页数，原 PDF 的 244 页不能用作修订版页数。

## 校验

`SOURCE_MANIFEST.json` 记录原始 ZIP 来源与 SHA-256，以及保留文件的校验信息。网页另外显示修订 ZIP 的 SHA-256，便于确认下载完整性。网页上的纸张预览是 HTML 版式示意，并非已渲染 PDF。