# 译稿审校报告

> 独立于翻译流程的复核记录。**本报告内容不进入正文**，仅作交付附件。
> 审校范围：`chapters/ch01.tex` — `ch06.tex` 及 `style/lecturestyle.sty`。
> 对照底本：EPUB `OEBPS/Text/chapter-1~6.html`（结构化抽取后逐段比对）。
>
> **第二轮（第 4–6 章）的复核追加在本报告第七节之后。**

---

## 一、完整性核查

按段落类型逐项清点，译稿与原文数量一致：

| 章 | 正文段 | 插图 | 图注 | 表格 | 代码清单 | 标注块 | 侧栏/警告 | 小结条目 |
|---|---|---|---|---|---|---|---|---|
| 第 1 章 | 全数 | 14 | 14 | 2 | 0 | 0 | 0 | 18 |
| 第 2 章 | 全数 | 9 | 9 | 3 | 12 | 12 | 2 | 11 |
| 第 3 章 | 全数 | 15 | 15 | 3 | 11 | 11 | 3 | 13 |

复核结论：

- 无删节、无归并、无「译者概括」。原文的重复表述（例如第 2 章 2.1.1 节正文与随后 NOTE 框中关于 RLHF 的说明几乎重复）**照原样保留**，未作合并——那是作者的编排，不是译者该动的。
- 原文的笔误也保留了原意而未擅自「修正」到看不出来的程度，例如：
  - 第 1 章「Then, When the agent is given a goal…」（原文有重复的 Then/When），译文顺为通顺中文，未引入新信息。
  - 第 2 章 `get_resource_url(research_soruce)`（原文拼写为 `soruce`），**代码原样保留**，因为读者若照抄运行必须与原书一致。
  - 第 3 章清单 3.11 原文 URL 写作 `http: //localhost:8000/ sse`（排版误插空格），译稿中修正为 `http://localhost:8000/sse`，因为这属于排版损伤而非作者本意，保留会导致代码不可运行。
- 第 2 章 2.3.3 节原文正文说「Run this code, and you will see the following error:」后面跟着两段 blockquote 报错信息，结构化抽取时曾漏掉，已回补为引用块。

## 二、语气与作者幽默的保全

原书是「有脾气」的技术写作，第一稿的主要风险是把口语调侃磨成技术手册腔。逐处核对如下，均已保留原味：

| 位置 | 原文 | 译稿处理 |
|---|---|---|
| 第 1 章 开篇 | *let your agents earn their keep in production* | 「让你的智能体在生产环境中真正挣回自己的饭钱」——保留了「挣饭钱」的俏皮，未译成「产生业务价值」 |
| 第 1 章 开篇 | *The examples stay deliberately small so the ideas stay sharp.* | 「示例会刻意保持精简，这样思想才能保持锋利」——保留 small/sharp 的对仗 |
| 第 1 章 1.4.3 | *such systems are chatty and repetitive* | 「这类系统*话痨且啰嗦*」——保留贬义口语，未译为「通信冗余」 |
| 第 2 章 2.2.2 | *Don't be alarmed if you can't follow this figure; it is just a toy example of complexity taken to the extreme.* | 「如果你看不懂这张图也别慌，它只是一个把复杂度推到极致的玩具例子」 |
| 第 2 章 2.2.3 | *don't be afraid to break up your masterpiece prompt* | 「别怕把你那份『大师级提示词』拆成更小的任务」——保留 masterpiece 的自嘲引号 |
| 第 2 章 2.4.1 | *If you allow an agent to delete files, expect it to delete all the files it has access to.* | 「那就等着它把权限所及的文件全删光吧」——保留威胁式冷幽默 |
| 第 2 章 2.3.2 侧栏 | *with deliberation reserved for the moments that earn it* | 「把深思熟虑留给真正配得上它的时刻」 |
| 第 3 章 3.3 | *Internal MCP for everything makes for clean architecture diagrams and noisy production systems.* | 「事事都用内部 MCP，换来的是漂亮的架构图和吵闹的生产系统」——保留反讽的并置结构 |
| 第 3 章 3.3.3 | *like a naive child, their interpretation of help may not always lead to the best outcomes* | 「就像个天真的孩子，它对『帮忙』的理解未必总能带来最好的结果」 |
| 第 3 章 警告框 | *Expect the unexpected.* | 「预料之外的事，要预先料到。」——保留格言体与斜体强调 |
| 第 3 章 3.4.1 | *The interface contract is the tool schema; the implementation is the server's private business.* | 「接口契约就是工具 schema，实现则是服务器自家的私事」——保留 private business 的拟人 |
| 第 3 章 3.2.1 | *because it wants to be helpful*（讲 LLM 多嘴加注） | 「因为它想帮上忙嘛」——补一个语气词还原原文的轻微揶揄 |
| 第 3 章 2.1.2 类比 | USB-C 之前每台设备各有接头 | 以「还记得……的日子吗？」起句，保留作者的回忆式亲切口吻 |

另：第 3 章 3.4 节作者刻意点明示例是虚构的（*The example is fabricated.*），这句自嘲式坦白也保留了（「这个例子是编出来的」），未美化为「本示例为说明性示例」。

## 三、术语与记号核查

统一表如下，全稿一致无摇摆：

| 英文 | 定译 | 备注 |
|---|---|---|
| agent | 智能体 | 不用「代理」，见正文《阅读说明》 |
| agentic | 智能体式的 | |
| agency | 能动性 | |
| persona | 人设 | 首现标注 system prompt 关系 |
| tool chaining | 工具链接 | |
| grounding | 接地 | |
| guardrail | 护栏 | |
| handoff | 交接 | |
| tokenization | 分词 | token 本身不译 |
| sense-plan-act-learn | 感知—规划—行动—学习（SPAL） | 破折号用连接号，非减号 |
| hub-and-spoke | 中心辐射式 | |
| LLM-as-judge | LLM 充当评委 | |
| retrieval-augmented generation | 检索增强生成（RAG） | |
| context window | 上下文窗口 | |
| prompt caching | 提示词缓存 | |

记号层面已修正的问题：

1. **数学符号误用**：原文表 2.1 中的 `≥`、`⇒`、`–2 … +2`，初稿混用了中文全角与文本符号，已统一为数学模式（`$\geq$`、`$\Rightarrow$`、`$-2$ \ldots $+2$`），排版后视觉一致。
2. **变量名斜体**：`top-p` 中的 *p* 是变量，原文为斜体，译稿统一为 `top-\emph{p}`，未写成正体 top-p。
3. **下划线转义**：所有 `\code{}` 中的 `_` 均已正确转义或走 `\tcode` 的 detokenize 路径，不会触发数学模式。
4. **引号**：正文一律中文直角引号「」；代码清单内的 ASCII 引号保持原样不替换。
5. **箭头**：图 1.3 图注中的 `>` 表示流程箭头，译文用 `$>$` 排版，未误作小于号。
6. **清单交叉引用**：初稿用 `\ref{lst:...}` 引用代码清单，因 tcolorbox 的 label 挂在 section 计数器上，会显示成「清单 2.3.2」这类错号，已改为直接书写「清单 2.12」等原书编号，与图/表的 `\ref` 机制分离。

## 四、机器翻译痕迹排查

逐章通读后处理的典型改法（列举，非穷举）：

| 类型 | 初稿倾向 | 已改为 |
|---|---|---|
| 被动语态直译 | 「工具被智能体所使用」 | 「智能体使用工具」 |
| 「的」字堆叠 | 「一个可被智能体自主调用的工具执行的端点」 | 「智能体可以自主调用的工具执行端点」 |
| 长定语前置 | 「在生产系统中被广泛采用的分级的人机协同管控」 | 「生产级智能体几乎总会实现分级的人机协同管控」（拆为主谓） |
| 连接词冗余 | 「因此，所以」「但是，然而」 | 择一 |
| it/this 直译 | 「这是重要的，理解这些错误」 | 「理解这些报错的含义……至关重要」 |
| 名词化 | 「进行工具的注册」 | 「注册工具」 |
| 英式插入语 | 「，其中，……，」三重逗号套嵌 | 改用破折号或拆句 |
| 计量表达 | 「两到五倍更昂贵」 | 「比输入贵上两到五倍」 |

另检查了几处易被机翻带偏的技术表述，确认语义正确：

- 第 2 章「The split matters because the model produces the same distribution for a given input.」——这里 split 指「模型出分布」与「采样出 token」两步的**拆分**，不是「分裂」；译文点明为「这种拆分很重要」并补足了因果逻辑。
- 第 3 章「the protocol is language agnostic at the wire level」——译作「在『线缆层面』是语言无关的」，保留原文的比喻而非直译为「有线级别」。
- 第 3 章「A given MCP server is either local or remote. There is no in between for a single server.」——译文强调「对单台服务器而言，不存在中间状态」，避免误读为「MCP 不支持混合部署」（作者紧接着就在纠正这个常见误解）。
- 第 1 章「Not all agents require or benefit from every layers」（原文 every layers 语法有误）——按语义译为「并非所有智能体都需要或能从每一层中受益」。

## 五、版面与可读性

- **代码框**：tcolorbox + listings，深蓝标题条 + 米白底 + 细边框 + 轻投影；行号灰色置左，长行自动折行并在续行处打 ↪ 标记。Manning 式行内标注（`#1`、`#2`）保留在代码中，中文解释以 ▷ 列表列于框下，不挤占代码区。
- **中英混排**：xeCJK 自动处理中西文间距；正文中文宋体、标题黑体、代码等宽，层次分明。
- **溢出**：最终编译仅剩 4 处 overfull，最大 14.8pt（约 5mm，出现在含长 npx 命令的表格内），已通过 `\tcode` 可断行命令压到不影响观感的程度；无 underfull 警告导致的版面塌陷。
- **交叉引用**：图/表全部通过 `\ref` 自动编号，编译后零 undefined reference。

## 六、遗留事项（供你决定，未擅自改动）

1. **原书笔误的处理尺度**。目前策略是「代码里的笔误保留，行文里的语病顺为通顺中文」。若你希望译稿加译注标出原文笔误（如 `research_soruce`），我可以补一套脚注体系。
2. **图片为原书英文插图**。图注已译，图内文字仍是英文。若需要汉化图内文字，得逐张重绘，工作量较大，且会偏离「忠实原文」的口径。
3. **第 2 章表 2.2 第二行**原文示例片段为 ``Task: Summarize in ≤100 words. Article: ` ``——末尾那个孤立的反引号是原书的分隔符示意，看着像残缺。已照原样保留。
4. **字体**。当前用 DejaVu（西文）+ Noto CJK（中文），是沙箱内可用字体。若你本地装了思源宋体/黑体，改 `style/lecturestyle.sty` 顶部四行即可，版式无需调整。

---
---

# 第二轮审校：第 4–6 章

> 与第一轮同一口径：独立于翻译流程，逐段对照 EPUB 原文复核。

## 一、完整性核查

| 章 | 正文段 | 插图 | 图注 | 表格 | 代码清单 | 标注块 | 侧栏 | 练习 | 小结条目 |
|---|---|---|---|---|---|---|---|---|---|
| 第 4 章 | 全数 | 10 | 10 | 4 | 12 | 12 | 1 | 5 | 13 |
| 第 5 章 | 全数 | 6 | 6 | 1 | 13 | 9 | 1 | 5 | 13 |
| 第 6 章 | 全数 | 12 | 12 | 3 | 9 | 9 | 1 | 5 | 11 |

复核结论：

- 三章正文逐段对应，无删节、无归并。第 4 章的四级标题（`####`，八种协调策略）在原书中是独立小节，译稿保留为 `\subsubsection` 层级，未压缩成列表。
- 原文中重复出现的段落照原样保留，未作合并。最典型的是第 6 章 6.4.5 节：「关于遗忘的理由」这一小标题下的头两段，与 6.4.3 节末尾的两段**几乎完全重复**（原文如此）。译稿两处都译了，因为这是作者的编排问题，不是译者该替他修的。
- 原文笔误的处理沿用第一轮口径：
  - 第 5 章清单 5.7 原文 `"""ee`（三引号后多了个 `ee`）、清单 5.8 的 `get_reflexion_solver_instructions` 被折行截断、`03_relexion_agents.py` 文件名少了个 `f`（应为 reflexion）——**代码内一律保留原样**。
  - 第 5 章清单 5.11 的标注编号原文从 `#5` 直接跳到 `#6`（缺 `#5` 对应项，`max_turns` 那条标为 `#6`）——保留原编号，未擅自续号。
  - 第 4 章清单 4.11 原文有一处字符串被折行打断（`"A research plan was not generated. Please try again #4 / with a different goal."`），保留原貌。
  - 第 4 章图 4.10 图注原文写作「shows *X* and *Y*」（作者显然是留了个占位没填）——照译为「显示了 *X* 与 *Y*」，未替作者补全。
- 第 4 章 4.1.3 节原文有一处段落被硬生生断开（"At the bottom" 与 "is the iterative critique pattern..." 分属两段），译文合为一句通顺中文，未增删信息。

## 二、语气与作者幽默的保全

第 4–6 章的调子比前三章更「老练」，作者频繁使用 *worth naming* / *the honest framing is* / *the practical test is* 这类「把话挑明」的句式，这是他的写作指纹，译稿统一保留为「值得点名」「老实的说法是」「实用的判别法是」，没有抹平成公文腔。

| 位置 | 原文 | 译稿处理 |
|---|---|---|
| 第 4 章 开篇 | *impressive in demos and brittle in practice* | 「在演示里惊艳，在实践中脆弱」——保留对仗 |
| 第 4 章 4.1.3 | *Treat agency as something the agent earns…, not something it is granted by default.* | 「把能动性当成智能体\*凭可靠表现挣来的东西\*，而不是默认就该发给它的东西」 |
| 第 4 章 4.1 | *what context earns its place at that step* | 「什么上下文\*配得上\*它占的那个位置」——保留拟人 |
| 第 4 章 4.3.2 | *past what your team can hold in their heads* | 「多到团队脑子里装不下时」 |
| 第 4 章 4.2.2 | *prompt chaining with superpowers*（小结条目） | 「开了外挂的提示链」 |
| 第 4 章 4.4.3 | *this can be fixed with some prompt magic* | 「靠些『提示词魔法』修好」——保留引号里的揶揄 |
| 第 4 章 4.1.3 | *This is overkill for…* | 「这么搞属于杀鸡用牛刀」 |
| 第 5 章 5.1.1 | *CoT is not a magic process* | 「CoT 并非什么神奇法术」 |
| 第 5 章 5.1.1 | *don't assume the CoT is broken* | 「别急着断定 CoT 坏掉了」 |
| 第 5 章 5.3.2 | *The "learning" framing … is misleading.* | 「早期 Reflexion 论文和教程里常见的那种『学习』说法是有误导性的」——保留对论文措辞的直接质疑 |
| 第 5 章 5.4 | *The name sequential thinking is a bit misleading because the server does no thinking* | 「这个名字略有误导，因为这台服务器\*并不思考\*」 |
| 第 6 章 6.3.2 | *The model is not cheating when it does this.* | 「模型这么做并不是在『作弊』」 |
| 第 6 章 6.4.1 | *The vocabulary is a tool, not a model.* | 「这套词汇是一件\*工具\*，不是一个\*模型\*」 |
| 第 6 章 小结 | *Memory and knowledge are siblings, not twins* | 「记忆与知识是兄弟，不是双胞胎」 |
| 第 6 章 小结 | *Grounding is nonnegotiable* | 「接地没得商量」 |
| 第 6 章 6.4.3 | *A few honest notes before moving on.* | 「在往下走之前，说几句实在话。」 |

第 5 章通篇的「时间旅行」例题保留了原文那种半开玩笑的科幻设定（Alex、角斗士、登月），未改写成中性的抽象题目。

## 三、术语与记号核查

新增术语，全稿一致：

| 英文 | 定译 | 出处 |
|---|---|---|
| handoff | 交接 | 第 4 章 |
| pass-off | 传递式 | 第 4 章 |
| tripwire | 绊线 | 第 4 章 |
| decision-making / control / communication / coordination | 决策 / 控制 / 通信 / 协调（四个 C） | 第 4 章 |
| hub-and-spoke | 中心辐射式 | 承接第 1 章 |
| fan-out / fan-in | 扇出 / 扇入 | 第 4 章 |
| best-of-N | N 中选优 | 第 4 章 |
| thundering herd | 惊群 | 第 4 章 |
| exponential backoff with jitter | 带抖动的指数退避 | 第 4 章 |
| decomposition / planning | 分解 / 规划 | 第 5 章 |
| chain-of-thought (CoT) | 思维链 | 第 5 章 |
| tree-of-thought (ToT) | 思维树 | 第 5 章 |
| Reflexion | Reflexion（不译，作为专名） | 第 5 章 |
| scratchpad | 草稿纸 | 第 5、6 章 |
| grounding | 接地 | 第 6 章，承接第 1 章 |
| hallucination | 幻觉 | 第 6 章 |
| dense / sparse vector | 稠密 / 稀疏向量 | 第 6 章 |
| Reciprocal Rank Fusion (RRF) | 倒数排名融合 | 第 6 章 |
| top-K | top-K（保留原形） | 第 6 章 |
| approximate nearest neighbor (ANN) | 近似最近邻 | 第 6 章 |
| episodic / semantic / procedural memory | 情景 / 语义 / 程序性记忆 | 第 6 章 |
| eviction | 逐出 | 第 6 章 |
| context dilution / lost in the middle | 上下文稀释 /「迷失在中间」 | 第 4 章 |

记号层面已处理：

1. **数学公式**。第 6 章的 TF-IDF 推导（TF、IDF、TF-IDF 三节）原文是行内纯文本，译稿改用 LaTeX 数学模式排版（`$\mathrm{TF} = 1 \div 6$`、`$\log_{10}(8 \div 4)$`、`$1 - \text{Cosine Similarity}(A,B)$`），公式对齐美观且不会被误折行。
2. **变量斜体**。`top-`*p*、top-`K`、best-of-*N*、矩阵的第 *i* 行第 *j* 列——变量一律斜体，与原文一致。
3. **箭头**。第 4 章流程「清洗 > 分析 > 摘要」、第 6 章「Semantic Search → Graph Search」等，正文用 `$>$` 或 `$\rightarrow$`，代码块内保持 ASCII `->`。
4. **比较符**。`< 10`、`≥ 7`、`≤ 0.5` 统一为 `$<$ 10`、`$\geq 7$`、`$<0.5$`。
5. **清单交叉引用**。沿用第一轮的做法，代码清单一律直书原书编号（「清单 4.12」），不走 `\ref`，避免 tcolorbox 计数器串到 section 上。
6. **长命令折行**。第 6 章表 6.3、第 4 章的 npx/schema 长串一律走 `\tcode`，可在任意字符处折行。

## 四、机器翻译痕迹排查

第 4–6 章里技术密度更高，最容易出机翻味的是那些嵌套从句。典型改法：

| 原文结构 | 直译倾向 | 已改为 |
|---|---|---|
| *An agent can have one without the other.* | 「一个智能体可以拥有一个而没有另一个。」 | 「一个智能体可以只有其中之一」 |
| *the shape of that flow is one of the commitments an architecture makes* | 「那个流的形状是一个架构做出的承诺之一」 | 「这条流转路径的形状，正是一种架构所作出的承诺之一」 |
| *Neither is universally right* | 「两者都不是普遍正确的」 | 「两者都不是放之四海皆准」 |
| *the same set of three workers … can be parallel flow or hierarchical coordination depending on whether…* | 长定语套嵌 | 拆为「同样是三个工人并发运行，到底算 A 还是 B，取决于……」 |
| *what looks like learning is the model producing better output when…* | 「看起来像学习的是模型产生更好的输出当……」 | 「看上去像学习的东西，其实是模型在输入里带上了……之后，产出了更好的输出」 |
| *The retrieval has no view into truth, only into similarity.* | 「检索没有对真相的视图」 | 「检索看不到\*真相\*，只看得到\*相似\*」 |
| *is "very likely the most similar" rather than guaranteed* | 「是『很可能最相似』而不是被保证的」 | 「是『很可能最相似』，而非有保证的最相似」 |
| *Internal MCP for everything makes for clean architecture diagrams and noisy production systems.* | 平铺直叙 | 保留反讽并置：「换来的是漂亮的架构图和吵闹的生产系统」 |

另核对了几处易被带偏的技术表述：

- 第 4 章 *the practical test is the orchestrator's job* ——这里 test 指「判别标准」不是「测试」，译作「实用的判别法是看编排者的职责」。
- 第 4 章 *A guardrail is a semantic circuit breaker* ——circuit breaker 是「断路器」（工程隐喻），不是「断路开关」，译作「语义层面的断路器」，并保留了作者强调它「有别于事后过滤」的那句对照。
- 第 5 章 *the model produces the same distribution for a given input. The decoding strategy … determines which token comes out.* ——这两句是在解释「模型出分布」与「采样出 token」的分工，译文补足了逻辑连接，避免读成两句无关的话。
- 第 5 章 *the global view is a property of the architecture, not the model* ——译作「全局视图是\*架构\*的属性，而非\*模型\*的属性」，这是本节的论点句，加了强调。
- 第 6 章 *"Sensory memory" is not a separate category in any meaningful sense* ——译作「在任何有意义的层面上都不是一个独立类别」，保留了作者对这套认知类比的保留态度。
- 第 6 章 *Dense vectors pack semantic meaning into every dimension* ——「稠密」修饰的是嵌入而非数据库，译文按原文点明了这一层。

## 五、版面与可读性

- 全书现为 **244 页**，零 undefined reference，零 missing character，零 float overflow。
- 第 2 章表 2.2（必备的提示技巧，10 行 4 列）原先超出单页 100pt，已改为 `longtable` 跨页排版，表头在续页自动重复。
- 最大残余 overfull 为 14.8pt（约 5mm），出现在第 3 章含长 npx 命令的表格内，不影响观感。
- 第 5 章清单 5.10（`SequentialThinking` 工具描述，60 余行纯文本）与第 6 章清单 6.9（混合记忆智能体指令，70 余行）都是超长代码块，`codelisting` 的 `breakable` 属性让它们跨页断开时边框与标题条衔接正常。
- 第 6 章的 TF-IDF 推导部分用了四级标题 + 行间公式，层次清楚。

## 六、遗留事项（未擅自改动）

1. **第 6 章 6.4.5 节的重复段落**。前面提过，「关于遗忘的理由」小节开头两段与 6.4.3 节末尾两段高度重复（仅多出一句关于受监管行业合规的补充）。这几乎肯定是原书的编辑疏漏。目前照原样保留；若你希望加一条译注点明，我可以补。
2. **第 4 章图 4.10 的图注占位符**。原文「shows *X* and *Y*」显然是作者没写完。已照译，未替他编内容。
3. **第 5 章小结提到「GPT-4o 家族」是 reasoning-native 模型**——这与 5.1 节正文的说法（o 系列才是显式推理模型，GPT-4o 属通用模型）略有出入，属于原书自身的不一致。正文与小结都按原文译出，未作统一。
4. **第 4 章表 4.4 有三处「何时不用」为空**（并行委派、条件路由、对等网络）。原文即为空白，译稿用「——」占位，保持表格结构完整。
5. **图片仍为原书英文插图**，图注已译。第 4–6 章新增 28 张图，均已收入 `figures/`。
